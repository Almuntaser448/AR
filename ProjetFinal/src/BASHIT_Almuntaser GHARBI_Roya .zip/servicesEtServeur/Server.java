package servicesEtServeur;

import java.io.IOException;
import java.net.ServerSocket;

/**
 * 
 * ce class est pour demarrer le serveur et les associer aux services concerne
 *
 */
public class Server implements Runnable {
	private ServerSocket listen_socket;

	public Server(int port) throws IOException {
		listen_socket = new ServerSocket(port);
	}

	public void run() {
		try {
			System.err.println("Lancement du serveur au port " + this.listen_socket.getLocalPort());

			while (true) {
				switch (this.listen_socket.getLocalPort()) {// ce switch est la pour differncer les serveices par raport
															// aux port assocsie
				case 3000:
					new Thread(new ServiceReservation(listen_socket.accept())).start();
					break;
				case 4000:
					new Thread(new ServiceEmprunt(listen_socket.accept())).start();
					break;
				case 5000:
					new Thread(new ServiceRetour(listen_socket.accept())).start();
				}
			}
		} catch (IOException e) {
			try {
				this.listen_socket.close();
			} catch (IOException e1) {
			}
			System.err.println("Arr�t du serveur au port " + this.listen_socket.getLocalPort());
		}
	}

	protected void finalize() throws Throwable {
		try {
			this.listen_socket.close();
		} catch (IOException e1) {
		}
	}
}
